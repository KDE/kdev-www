#ifndef PREFSTYLE_H
#define PREFSTYLE_H

#include <qwidget.h>
#include <prefstylelayout.h>

class PrefStyle : public PrefStyleLayout {
    Q_OBJECT
  public:
    PrefStyle(QWidget *parent, const char *name=0, WFlags f=0);
};

#endif  // PREFSTYLE_H
