#ifndef CONFIGURATION_H
#define CONFIGURATION_H

#include <qstring.h>
#include <qfont.h>
#include <qcolor.h>

/// This is the one and only configuration object.
/// The member functions read() and write() can be used to load and save
/// the properties to the application configuration file.
class Configuration {
  public:
    /// Reads the configuration data from the application config file.
    /// If a property does not already exist in the config file it will be
    /// set to a default value.
    void read();
    /// Writes the configuration data to the application config file.
    void write() const;

    QString m_text;         ///< The text to be printed in the main widget.
    QFont   m_font;         ///< The font to be used for the text.
    QColor  m_textColor;    ///< The text colour used in the main widget.

  private:
    Configuration();
    Configuration(const Configuration&);

    friend Configuration& Config();
};

/// Returns a reference to the application configuration object.
Configuration& Config();

#endif  // CONFIGURATION_H
