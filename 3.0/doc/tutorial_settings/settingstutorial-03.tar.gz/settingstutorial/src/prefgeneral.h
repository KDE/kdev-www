#ifndef PREFGENERAL_H
#define PREFGENERAL_H

#include <qwidget.h>
#include <prefgenerallayout.h>

/// This is the implementation if the "general options" page of the preferences dialog.
class PrefGeneral : public PrefGeneralLayout {
    Q_OBJECT
  public:
    /// Default constructor
    PrefGeneral(QWidget *parent, const char *name=0, WFlags f=0);
};

#endif  // PREFGENERAL_H
