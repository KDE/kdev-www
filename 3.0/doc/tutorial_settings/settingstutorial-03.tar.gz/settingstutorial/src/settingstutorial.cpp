#include "settingstutorial.h"
#include "settingstutorial.moc"

#include <qlabel.h>

#include <kmainwindow.h>
#include <klocale.h>

SettingsTutorial::SettingsTutorial() : KMainWindow( 0, "SettingsTutorial" ) {
    setXMLFile("settingstutorialui.rc");
    new QLabel( "Hello World", this, "hello label" );
}

SettingsTutorial::~SettingsTutorial()
{
}
