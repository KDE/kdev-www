#ifndef CONFIGURATION_H
#define CONFIGURATION_H

class Configuration {
  public:
    // add some public members (the user settings)
  private:
    Configuration();
    Configuration(const Configuration&);

    // allow this function to create one instance
    friend Configuration& Config();
};

// use this function to access the settings
Configuration& Config();

#endif  // CONFIGURATION_H
