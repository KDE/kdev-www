#include "configuration.h"

Configuration::Configuration() {
    // TODO: Initialisation of user settings
};

Configuration& Config() {
    static Configuration conf;
    return conf;
};
