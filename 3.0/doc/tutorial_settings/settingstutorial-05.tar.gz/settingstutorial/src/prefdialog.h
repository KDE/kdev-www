#ifndef PREFDIALOG_H
#define PREFDIALOG_H

#include <qwidget.h>
#include <kdialogbase.h>

class PrefGeneral;
class PrefStyle;

/// The preferences dialog.
class PrefDialog : public KDialogBase {
    Q_OBJECT
  public:
    /// Constructor
    PrefDialog(QWidget *parent, const char *name=0, WFlags f=0);

    /// Transfers the settings from the configuration object to the dialog.
    void updateDialog();
    /// Transfers the settings from the dialog to the configuration object.
    void updateConfiguration();

  private:
    PrefGeneral    *m_prefGeneral;
    PrefStyle      *m_prefStyle;
};

#endif  // PREFDIALOG_H
