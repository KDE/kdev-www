#include <qevent.h>         // for QMouseEvent
#include <qlayout.h>        // for QVBoxLayout
#include <klocale.h>        // for i18n()
#include <kpushbutton.h>    // for KPushButton

#include "settingstutorial.h"
#include "settingstutorial.moc"

#include "prefdialog.h"     // class PrefDialog
#include "configuration.h"  // class Configuration and Config()

SettingsTutorial::SettingsTutorial()
  : KMainWindow( 0, i18n("SettingsTutorial") ), m_prefDialog(0)
{
    m_theTextButton = new KPushButton( this );
    setCentralWidget(m_theTextButton);
    applyPreferences();

    connect( m_theTextButton, SIGNAL( clicked() ), this, SLOT( executePreferencesDlg() )  );
}

void SettingsTutorial::executePreferencesDlg() {
    if (m_prefDialog==0)
        m_prefDialog=new PrefDialog(this);          // create dialog on demand
    m_prefDialog->updateDialog();                   // update the dialog widgets
    if (m_prefDialog->exec()==QDialog::Accepted) {  // execute the dialog
        m_prefDialog->updateConfiguration();        // store settings in config object
        applyPreferences();                         // let settings take effect
    };
};

void SettingsTutorial::applyPreferences() {
    Config().write();
    m_theTextButton->setText( Config().m_text );
    m_theTextButton->setPaletteForegroundColor( Config().m_textColor );
    m_theTextButton->setFont( Config().m_font );
};

