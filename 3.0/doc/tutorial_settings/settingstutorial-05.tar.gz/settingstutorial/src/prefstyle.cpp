#include <qfont.h>          // for QFont
#include <kpushbutton.h>    // for KPushButton
#include <kfontdialog.h>    // for KFontDialog
#include <qlabel.h>

#include "prefstyle.h"
#include "prefstyle.moc"

PrefStyle::PrefStyle(QWidget *parent, const char *name, WFlags f)
 : PrefStyleLayout(parent, name, f)
{
    connect(m_fontBtn, SIGNAL( clicked() ), this, SLOT( chooseBtnClicked() )  );
}

void PrefStyle::chooseBtnClicked() {
    QFont tmpFont = m_fontLabel->font();
    int result = KFontDialog::getFont(tmpFont);
    if (result==KFontDialog::Accepted)
        m_fontLabel->setFont(tmpFont);
};
