#include <qlayout.h>        // for QVBoxLayout
#include <qlabel.h>         // for QLabel
#include <qframe.h>         // for QFrame
#include <kcolorbutton.h>   // for KColorButton
#include <kpushbutton.h>    // for KPushButton
#include <klocale.h>        // for i18n()
#include <kiconloader.h>    // for KIconLoader
#include <kglobal.h>        // for KGlobal
#include <klineedit.h>      // for KLineEdit
#include <kmessagebox.h>    // for KMessageBox

#include "prefdialog.h"     // class PrefDialog
#include "prefdialog.moc"

#include "configuration.h"  // class Configuration and Config()
#include "prefgeneral.h"    // class PrefGeneral
#include "prefstyle.h"      // class PrefStyle

PrefDialog::PrefDialog(QWidget *parent, const char *name, WFlags f)
 : KDialogBase(IconList, i18n("Preferences"), Default|Ok|Apply|Cancel, Ok, parent, name, f)
{
    // adding page "General options"
    QFrame *frame = addPage(i18n("General"), i18n("General options"),
        KGlobal::iconLoader()->loadIcon("kfm",KIcon::Panel,0,false) );
    QVBoxLayout *frameLayout = new QVBoxLayout( frame, 0, 0 );
    m_prefGeneral = new PrefGeneral(frame);
    frameLayout->addWidget(m_prefGeneral);

    // adding page "Style settings"
    frame = addPage(i18n("Style"), i18n("Style settings"),
        KGlobal::iconLoader()->loadIcon("style",KIcon::Panel,0,false) );
    frameLayout = new QVBoxLayout( frame, 0, 0 );
    m_prefStyle = new PrefStyle(frame);
    frameLayout->addWidget(m_prefStyle);

    // connect interactive widgets and selfmade signals to the enableApply slotDefault
    connect( m_prefGeneral->m_textEdit, SIGNAL( textChanged(const QString&) ), this, SLOT( enableApply() )  );
    connect( m_prefStyle->m_colorBtn, SIGNAL( changed(const QColor&) ), this, SLOT( enableApply() )  );
    connect( m_prefStyle, SIGNAL( fontChanged() ), this, SLOT( enableApply() )  );
};


void PrefDialog::updateDialog() {
    m_prefGeneral->m_textEdit->setText( Config().m_text );
    m_prefStyle->m_colorBtn->setColor( Config().m_textColor );
    m_prefStyle->m_fontLabel->setFont( Config().m_font );
    enableButtonApply(false);   // disable apply button
};


void PrefDialog::updateConfiguration() {
    Config().m_text         = m_prefGeneral->m_textEdit->text();
    Config().m_textColor    = m_prefStyle->m_colorBtn->color();
    Config().m_font         = m_prefStyle->m_fontLabel->font();
    enableButtonApply(false);   // disable apply button
};


void PrefDialog::slotDefault() {
    if (KMessageBox::warningContinueCancel(this, i18n("This will set the default options "
        "in ALL pages of the preferences dialog! Continue?"), i18n("Set default options?"),
        i18n("Set defaults"))==KMessageBox::Continue)
    {
        m_prefGeneral->m_textEdit->setText( Config().m_defaultText );
        m_prefStyle->m_colorBtn->setColor( Config().m_defaultTextColor );
        m_prefStyle->m_fontLabel->setFont( Config().m_defaultFont );
        enableApply();   // enable apply button
    };
};


void PrefDialog::slotApply() {
    updateConfiguration();      // transfer settings to configuration object
    emit settingsChanged();     // apply the preferences
    enableButtonApply(false);   // disable apply button again
};


void PrefDialog::enableApply() {
    enableButtonApply(true);   // enable apply button
};
