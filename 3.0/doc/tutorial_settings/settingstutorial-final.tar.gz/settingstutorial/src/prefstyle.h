#ifndef PREFSTYLE_H
#define PREFSTYLE_H

#include <qwidget.h>
#include <prefstylelayout.h>

/// Implementation of the "Style settings" page of the preferences dialog.
class PrefStyle : public PrefStyleLayout {
    Q_OBJECT
  public:
    /// Constructor.
    PrefStyle(QWidget *parent, const char *name=0, WFlags f=0);

  private slots:
    /// Called whenever the "Choose..." button is clicked.
    void chooseBtnClicked();

  signals:
    /// Will be emitted when the user selected a different font.
    void fontChanged();
};

#endif  // PREFSTYLE_H
