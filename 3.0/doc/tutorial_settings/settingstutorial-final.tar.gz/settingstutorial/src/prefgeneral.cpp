#include "prefgeneral.h"
#include "prefgeneral.moc"

PrefGeneral::PrefGeneral(QWidget *parent, const char *name, WFlags f)
 : PrefGeneralLayout(parent, name, f)
{
    // TODO: initialisation of the widgets
}
