#ifndef PREFDIALOG_H
#define PREFDIALOG_H

#include <qwidget.h>
#include <kdialogbase.h>

class PrefGeneral;
class PrefStyle;

/// The preferences dialog.
class PrefDialog : public KDialogBase {
    Q_OBJECT
  public:
    /// Constructor
    PrefDialog(QWidget *parent, const char *name=0, WFlags f=0);

    /// Transfers the settings from the configuration object to the dialog.
    void updateDialog();
    /// Transfers the settings from the dialog to the configuration object.
    void updateConfiguration();

  public slots:
    /// Will be called when the "Default" button has been clicked.
    void slotDefault();
    /// Will be called when the "Apply" button has been clicked.
    void slotApply();
    /// Will be called whenever a setting was changed.
    void enableApply();

  signals:
    /// Will be emitted when the new settings should be applied.
    void settingsChanged();

  private:
    PrefGeneral    *m_prefGeneral;
    PrefStyle      *m_prefStyle;
};

#endif  // PREFDIALOG_H
