#include <kapplication.h>       // for 'kapp'
#include <kconfig.h>            // for KConfig
#include <klocale.h>            // for i18n()

#include "configuration.h"

const QString Configuration::m_defaultText = i18n("Hello World");
const QFont   Configuration::m_defaultFont = QFont("Helvetica");
const QColor  Configuration::m_defaultTextColor = Qt::black;

Configuration::Configuration() {
    read(); // read the settings or set them to the default values
};

void Configuration::read() {
    KConfig *conf=kapp->config();
    // read general options
    conf->setGroup("General");
    m_text = conf->readEntry("text", m_defaultText );
    // read style options
    conf->setGroup("Style");
    m_font = conf->readFontEntry("font", &m_defaultFont );
    m_textColor = conf->readColorEntry("textColor", &m_defaultTextColor );
};

void Configuration::write() const {
    KConfig *conf=kapp->config();
    // write general options
    conf->setGroup("General");
    conf->writeEntry("text",       m_text);
    // write style options
    conf->setGroup("Style");
    conf->writeEntry("font",       m_font);
    conf->writeEntry("textColor",  m_textColor);
};

Configuration& Config() {
    static Configuration conf;
    return conf;
};
