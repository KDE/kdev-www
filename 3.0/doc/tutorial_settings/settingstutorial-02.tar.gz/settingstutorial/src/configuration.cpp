#include "configuration.h"

#include <kapplication.h>       // for 'kapp'
#include <kconfig.h>            // for KConfig

Configuration::Configuration() {
    read(); // read the settings or set them to the default values
};

void Configuration::read() {
    KConfig *conf=kapp->config();

    // read general options
    conf->setGroup("General");
    m_text = conf->readEntry("text", "Hello World");

    // read style options
    conf->setGroup("Style");
    QFont defaultFont = QFont("Helvetica");
    m_font = conf->readFontEntry("font", &defaultFont);
    QColor defaultColor(0,0,50);
    m_textColor = conf->readColorEntry("textColor", &defaultColor);
};

void Configuration::write() const {
    KConfig *conf=kapp->config();
    // write general options
    conf->setGroup("General");
    conf->writeEntry("text",       m_text);
    // write style options
    conf->setGroup("Style");
    conf->writeEntry("font",       m_font);
    conf->writeEntry("textColor",  m_textColor);
};

Configuration& Config() {
    static Configuration conf;
    return conf;
};
