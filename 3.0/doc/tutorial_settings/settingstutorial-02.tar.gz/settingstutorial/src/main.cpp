/*
 * Copyright (C) 2003 gfd <kdeinstall@bwfan1>
 */

#include "settingstutorial.h"
#include <kapplication.h>
#include <kaboutdata.h>
#include <kcmdlineargs.h>
#include <klocale.h>

static const char *description =
    I18N_NOOP("A KDE KPart Application");

static const char *version = "0.1";

static KCmdLineOptions options[] =
{
//    { "+[URL]", I18N_NOOP( "Document to open." ), 0 },
    { 0, 0, 0 }
};

int main(int argc, char **argv)
{
    KAboutData about("settingstutorial", I18N_NOOP("SettingsTutorial"), version, description,
                     KAboutData::License_GPL, "(C) 2003 gfd", 0, 0, "kdeinstall@bwfan1");
    about.addAuthor( "gfd", 0, "kdeinstall@bwfan1" );
    KCmdLineArgs::init(argc, argv, &about);
    KCmdLineArgs::addCmdLineOptions( options );
    KApplication app;
    SettingsTutorial *mainWin = 0;

    if (app.isRestored())
    {
        RESTORE(SettingsTutorial);
    }
    else
    {
        // no session.. just start up normally
        KCmdLineArgs *args = KCmdLineArgs::parsedArgs();

        // TODO: do something with the command line args here

        mainWin = new SettingsTutorial();
        app.setMainWidget( mainWin );
        mainWin->show();

        args->clear();
    }

    int ret = app.exec();

    delete mainWin;
    return ret;
}
