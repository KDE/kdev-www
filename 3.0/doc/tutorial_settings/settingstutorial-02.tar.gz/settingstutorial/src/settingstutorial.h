#ifndef _SETTINGSTUTORIAL_H_
#define _SETTINGSTUTORIAL_H_

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <kmainwindow.h>

class SettingsTutorial : public KMainWindow {
    Q_OBJECT
  public:
    SettingsTutorial();
    virtual ~SettingsTutorial();
};

#endif // _SETTINGSTUTORIAL_H_
