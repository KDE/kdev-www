#include "prefstyle.h"
#include "prefstyle.moc"

PrefStyle::PrefStyle(QWidget *parent, const char *name, WFlags f)
 : PrefStyleLayout(parent, name, f)
{
}
