#ifndef _SETTINGSTUTORIAL_H_
#define _SETTINGSTUTORIAL_H_

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <kmainwindow.h>

class QMouseEvent;
class KPushButton;
class PrefDialog;

/// This is the main window of the tutorial program.
class SettingsTutorial : public KMainWindow {
    Q_OBJECT
  public:
    /// Default constructor.
    SettingsTutorial();

  public slots:
    /// Executes the preferences dialog.
    void executePreferencesDlg();
    /// Updates the widgets so that new user settings take effect.
    void applyPreferences();

  private:
    KPushButton    *m_theTextButton;
    PrefDialog     *m_prefDialog;
};

#endif // _SETTINGSTUTORIAL_H_
